<?php
/**
* BreezingForms - A Joomla Forms Application
* @version 1.7.3
* @package BreezingForms
* @copyright (C) 2008-2011 by Markus Bopp
* @license Released under the terms of the GNU General Public License
**/

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

class  Sh404sefExtpluginCom_BreezingForms extends Sh404sefClassBaseextplugin {

  protected $_extName = 'com_breezingforms';
    
  public function __construct( $option, $config) {

    parent::__construct( $option, $config);
    $this->_pluginType = Sh404sefClassBaseextplugin::TYPE_SH404SEF_ROUTER;

  }
    
  protected function _findSefPluginPath( $nonSefVars = array()) {
    
    $this->_sefPluginPath =  JPATH_ROOT . DS. 'plugins'.DS.'sh404sefextplugins'.DS.'breezingforms'.DS.'com_breezingforms.php';

  }

}